#!/bin/sh
mountpath="/mnt"
script="usb_upgrade"
satacount=`/img/bin/check_service.sh "satacount"`
if [ "${satacount}" == "" ];
then
	satacount=5
fi

is_new_version=`cat /img/version | cut -c 1-4| awk '{ if (($0*100) > 200) print "yes"}'`
if [ "${is_new_version}" == "yes" ];then
    #echo "newer version: > v2.01.00"
    talktolcm="/img/bin/model/talktolcm.sh"
else
    #echo "older version"
    talktolcm="lcm"
fi
function lcm(){
    echo $1 $2 $3 $4 >/tmp/avrpipe
}
function led(){
    echo $1 $2 >/proc/thecus_io
}


strExec="cat /proc/scsi/scsi|awk  '/Thecus:/{FS=\" \";printf(\"%s:%s\n\",\$2,\$3)}'|awk -F: '{if (\$2>"${satacount}") {printf(\"%s\n\",\$4)}}'"
normal=`eval ${strExec}`
for i in $normal ;
do
    strExec="cat /proc/partitions|awk '/${i}/{FS=\" \";print \$4}'"
    mount_usbs=`eval ${strExec}`
    for mount_usb in $mount_usbs ;
    do
        #create folder
        strexec="mount|awk '/\/dev\/${mount_usb}/&&/\/mnt/'"
        chkmount=`eval ${strexec}`
        if [ "${chkmount}" == "" ];
        then
            mount "/dev/${mount_usb}" "${mountpath}"
            #/bin/mount -t vfat -o iocharset=utf8,umask=0,fmask=001,uid=99,gid=99 "/dev/${mount_usb}" "${mountpath}"
            if [ $? = 0 ];
            then
                if [ -f ${mountpath}/${script} ];
                then
                    cp ${mountpath}/${script} /tmp
                fi
                if [ -f "${mountpath}/usb_reset_default" ]; then
                    touch /tmp/usb_reset_default
                fi
                if [ -f "${mountpath}/usb_reset_passwd" ]; then
	            touch /tmp/usb_reset_passwd
                fi
            fi
        else
            if [ -f ${mountpath}/${script} ];
            then
                cp ${mountpath}/${script} /tmp
            fi
            if [ -f "${mountpath}/usb_reset_default" ]; then
                touch /tmp/usb_reset_default
            fi
            if [ -f "${mountpath}/usb_reset_passwd" ]; then
      	        touch /tmp/usb_reset_passwd
            fi
        fi
        sync
        umount ${mountpath}
    done
done

if [ -e "/tmp/${script}" ]; then
    /tmp/${script}
	/img/bin/model/sysdown.sh poweroff &
    exit 0
elif [ -f "/tmp/usb_reset_default" ]; then
    rm -f "/tmp/usb_reset_default"
    /img/bin/resetDefault.sh &
    /img/bin/model/sysdown.sh poweroff &
    exit 0
elif [ -f "/tmp/usb_reset_passwd" ]; then
    rm -f "/tmp/usb_reset_passwd"
    /img/bin/chpwd.sh admin
    printf "admin\nadmin\n" | /opt/samba/bin/smbpasswd -a -s admin
    /img/bin/reset_passwd.sh
    rm -f /app/factory_test.sh
    /img/bin/model/sysdown.sh poweroff &
    exit 0
else
    ${talktolcm} agent2 0 BTMSG "No script"
    sleep 10
    exit 1
fi
