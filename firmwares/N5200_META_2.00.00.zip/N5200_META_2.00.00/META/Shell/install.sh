#!/bin/sh
###############################################################################
##
##  Module install script
##
###############################################################################

modName=META

###############################################################################
##
##  Include module library
##
###############################################################################
shellDir="/raid/data/module/$modName/Shell"
[ ! -d "$shellDir" -o ! -r "$shellDir/module.lib" ] && shellDir=/raid/data/tmp/module/Shell
{ [ -r "$shellDir/module.lib" ] && source "$shellDir/module.lib"; } || { echo fail; exit 1; }

###############################################################################
##
##  Start the module installation
##
###############################################################################
ModuleInstallStart

###############################################################################
##
##  Module specific installation stuff
##
###############################################################################

for script in ; do
    echo "Setting file attribs for: $modDir/system/$script" >>$modLog
    FileAttr root root 755 $modDir/system/$script >>$modLog 2>&1
done

echo "Creating startup and shutdown directories..." >>$modLog
for dir in startup shutdown ; do
    echo "    Creating $modDir/system/etc/$dir" >>$modLog
    mkdir $modDir/system/etc/$dir >>$modLog 2>&1
    FileAttr root root 755 $modDir/system//etc/$dir >>$modLog 2>&1
done
 
###############################################################################
##
##  Finish module installation indicating success
##
###############################################################################
ModuleInstallEnd 0
