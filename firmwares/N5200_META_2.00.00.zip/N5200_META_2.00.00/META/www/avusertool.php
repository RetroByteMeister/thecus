<?php
//############################################################################
//
//  avusertool.php
//
//  Prerequisites:
//      $modName needs to be set!
//      system/usertool is used
//
//  2007-01-16  Andreas Vogel (omega)
//
//############################################################################

$userTool = '/raid/data/module/'.$modName.'/system/usertool';

//############################################################################
//
//  Change the password for a user.
//
//############################################################################
function ChangePassword($user,$password,$show) {
    global $modName;

    if ($password != "") {
        $cmd = $userTool.' change "'.$user.'" "'.$password.'" &>/dev/null && echo OK';
        $status = trim (shell_exec($cmd));

        if ($status == "OK") {
            if ($show == 1) {
                print('<p><hr><p>Operation complete: set password for user <b>'.$user.'</b> to "<b>'.$password.'</b>"!<p><hr><p>');
            } else {
                print('<p><hr><p>Operation complete: set password for user <b>'.$user.'</b> to "<b>*******</b>"!<p><hr><p>');
            }
        } else {
            print('<p><hr><p>ERROR: cannot set password for user <b>'.$user.'</b> to "<b>'.$password.'</b>"!<p><hr><p>');
        }
    }
}

//############################################################################
?>
