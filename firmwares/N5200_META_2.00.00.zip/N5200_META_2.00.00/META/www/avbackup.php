<?php
//############################################################################
//
//  avbackup.php
//
//  Prerequisites:
//      $modName needs to be set!
//      system/configtool is used
//
//  2007-01-16  Andreas Vogel (omega)
//
//############################################################################

$cfgTool = '/raid/data/module/'.$modName.'/system/configtool';

//############################################################################
//
//  Create a persistent backup of the module configuration.
//  The configuration file is stored in /raid/data/module/backup/$modName
//
//############################################################################
function Backup(){
    global $cfgTool, $modName;

    $cmd = $cfgTool.' backup "'.$modName.'" &>/tmp/avbackup.err && echo OK';
    $status = trim (shell_exec ($cmd));

    if ($status == "OK") {
        print('<p><hr><p>Backup completed: '.$modName.' configuration files saved!<p><hr><p>');
    } else {
        $error = shell_exec ('cat /tmp/avbackup.err');
        print('<p><hr><p>ERROR: '.$modName.' configuration files couldn\'t be saved!<p>'.$error.'<p><hr><p>');
    }
    shell_exec ('rm -f /tmp/avbackup.err');
}

//############################################################################
//
//  Restore the persistent backup of the module configuration.
//  The configuration file is taken from /raid/data/module/backup/$modName
//
//############################################################################
function Restore(){
    global $cfgTool, $modName;

    $cmd = $cfgTool.' restore "'.$modName.'" &>/tmp/avrestore.err && echo OK';
    $status = trim (shell_exec ($cmd));

    if ($status == "OK") {
        print('<p><hr><p>Restore completed: '.$modName.' configuration files restored!<p><hr><p>');
    } else {
        $error = shell_exec ('cat /tmp/avrestore.err');
        print('<p><hr><p>ERROR: '.$modName.' configuration files couldn\'t be restored!<p>'.$error.'<p><hr><p>');
    }
    shell_exec ('rm -f /tmp/avrestore.err');
}

//############################################################################
?>
